# Import necessary libraries
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report
import tkinter as tk
from tkinter import messagebox

# Load and prepare the dataset
data = pd.read_csv("C:/Users/Archana S Ghadage/Documents/Archana/Try/Machine_Learning/spam_csv/spam.csv", encoding='ISO-8859-1')

# Drop unnecessary columns and keep only the first two columns: 'v1' (Label) and 'v2' (EmailText)
data = data[['v1', 'v2']]
data.columns = ['Label', 'EmailText']

# Split the data into features and labels
X = data['EmailText']
y = data['Label']

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Vectorize the text data using TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

# Train the Naive Bayes model
model = MultinomialNB()
model.fit(X_train_tfidf, y_train)

# Function to classify input text
def classify_email():
    email_text = entry.get()  # Get text from the input field
    if not email_text:
        messagebox.showwarning("Input Error", "Please enter a message to classify.")
        return
    
    # Vectorize the input email
    email_tfidf = vectorizer.transform([email_text])
    
    # Predict if it's spam or not
    prediction = model.predict(email_tfidf)
    
    # Show the result in the GUI
    result_label.config(text=f"Prediction: {prediction[0]}")
    
# Function to display model accuracy
def show_accuracy():
    y_pred = model.predict(X_test_tfidf)
    accuracy = accuracy_score(y_test, y_pred)
    messagebox.showinfo("Model Accuracy", f"Accuracy: {accuracy * 100:.2f}%")

# Create the main window
root = tk.Tk()
root.title("Spam Detector")
root.geometry("400x300")

# Add GUI components
label = tk.Label(root, text="Enter your email/message:")
label.pack(pady=10)

entry = tk.Entry(root, width=50)
entry.pack(pady=10)

# Add buttons
classify_button = tk.Button(root, text="Classify Email", command=classify_email)
classify_button.pack(pady=10)

accuracy_button = tk.Button(root, text="Show Model Accuracy", command=show_accuracy)
accuracy_button.pack(pady=10)

# Label to show the classification result
result_label = tk.Label(root, text="")
result_label.pack(pady=10)

# Run the Tkinter event loop
root.mainloop()
